console.log('1' > 4); //false
console.log('' <= 1); // true
console.log('apple' > 'pineapple'); //false
console.log(undefined == null); //true
console.log(undefined === null); //false
console.log(NaN !== 2); //true
console.log(NaN == NaN); //false
console.log(NaN === NaN) //false
