let BRAND_NAME = "I am Hero!"
alert(BRAND_NAME);