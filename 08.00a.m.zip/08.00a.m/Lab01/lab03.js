let name = "Jathupol";
let surname = "Pimkal";
let age = "22";
let home = "mahasarakham";
console.log = ("Full name :" +name+ surname + ",Age :" + age +",Address : "+ home) ;