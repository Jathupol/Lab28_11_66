// //------------Lab01--------------
// let person;
// let name;

// name = "Jathupol";
// person = "name";

// alert(person);
// //------------Lab02---------------
// let myMony;
// let myfather;
// let mymathrer;
// let myAddress;
// let myAge;
// //-------------Lab03-------------------
// let name01 = "Jathupol";
// let surname = "Pimkal";
// let age = "22";
// let home = "mahasarakham";
// console.log = ("Full name :" +name01+ surname + ",Age :" + age +",Address : "+ home) ;
// //--------------Lab04-----------------
// const firstName = 'Jathupol'; 
// let lastName = 'Pimkal'; 
// var nickname = 'Pond'; 

// const firstName = 'Piya';
// let lastName = 'Phonluea';
// var nickname = 'Dung';

// birthDate = '16/12/2001';
// //--------------Lab05----------------
// let firstName01 = 'Jathupol';
// let lastName01 = 'Pimkal';
// let myage = 22;
// let address = 'Mahasarakham';

// console.log(`Full Name: ${firstName} ${lastName}, Age: ${myage}, Address: ${address}`);
// //------------Lab06------------------
// let BRAND_NAME = "I am Hero!"
// alert(BRAND_NAME);
// //------------Lab07------------------
// const country = 'Thailand';
// const continent = 'Asia';
// console.log(`number is ${2}`);
// console.log(`result is ${1 + 3}`);
// console.log(`I live in ${country}`);
// console.log(`I live in ${country}, ${continent}`);
// console.log(`I live in ${country + ', ' + continent}`);
// console.log(`I live in ${'country, continent'}`);
// //------------------------------------
