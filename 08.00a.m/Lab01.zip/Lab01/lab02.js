let myMony;
let myfather;
let mymathrer;
let myAddress;
let myAge;

myMony = 100;
myfather = "Jaroon";
mymathrer = "sopa";
myAddress = "mahssarakham";
myAge = 22;

console.log(myMony, myfather, mymathrer, myAddress, myAge);
