const firstName = 'Jathupol'; 
let lastName = 'Pimkal'; 
var nickname = 'Pond'; 

firstName = 'Piya';
lastName = 'Phonluea';
nickname = '';

let birthDate = '16/12/2001';
