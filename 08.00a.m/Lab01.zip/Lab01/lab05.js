let firstName = 'Jathupol';
let lastName = 'Pimkal';
let age = 22;
let address = 'Mahasarakham';

console.log(`Full Name: ${firstName} ${lastName}, Age: ${age}, Address: ${address}`);
